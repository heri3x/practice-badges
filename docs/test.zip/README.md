[![logo](https://user-images.githubusercontent.com/17685618/161884562-a0c51e88-00fe-42e6-a889-9470dce4d94c.png)](https://github.com/heri3x/practice-badges/)

バッジの練習用。

[![GitHub release (latest by date)](https://img.shields.io/github/v/release/heri3x/practice-badges?display_name=release)](https://github.com/heri3x/practice-badges/releases/latest)
[![CI](https://github.com/heri3x/practice-badges/workflows/CI/badge.svg)](https://github.com/heri3x/practice-badges/actions/workflows/ci.yml)
[![page-changed](https://github.com/heri3x/practice-badges/workflows/page-changed/badge.svg)](https://github.com/heri3x/practice-badges/actions/workflows/page-changed.yml)
[![pages-build-deployment](https://github.com/heri3x/practice-badges/actions/workflows/pages/pages-build-deployment/badge.svg)](https://github.com/heri3x/practice-badges/actions/workflows/pages/pages-build-deployment)

## ドキュメントページ

[practice-badgesドキュメント](https://heri3x.github.io/practice-badges/)

## ライセンス

[MITライセンス](./LICENSE)
